# API reference (server-to-server)

Base URL (test): `https://ecom-api-test.paynet.md`. All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

## POST /api/linked-cards/unlink — Delete linked card

The delete linked card method is used to deactivate and remove a previously linked card from the Paynet system. When this method is executed, the specified card token is permanently invalidated, and the card is unlinked from the customer account. As a result, the token can no longer be used for any payment operations, including recurring or one-click payments. To perform this request, the Partner must provide the unique card identifier (CardLinkHash), the corresponding SaleAreaCode, and the CustomerCode associated with the card. This method ensures that sensitive payment credentials are securely removed and prevents any further unauthorized or unintended use.

Request body (`DeleteLinkedCardRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `CardLinkHash` | string | yes | The unique hash identifying the specific card to be unlinked. |
| `SaleAreaCode` | string | yes | The code identifying the specific sale area or merchant environment. |
| `CustomerCode` | string | yes | The unique identifier or code of the customer who owns the linked card. |

Request example:

```json
{
  "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3",
  "SaleAreaCode": "onlidocumentation_md",
  "CustomerCode": "customer_code"
}
```

Response `200` — Success executed unlink card.:

```json
{
  "responseCode": "SUCCESS"
}
```

Response `400` — Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.:

```json
{
  "errorInfo": {
    "type": "https://tools.ietf.org/html/rfc9110#section-15.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "detail": null,
    "instance": null,
    "ppResponseCodeEnum": "TECHNICAL_ERROR",
    "ppResponseCode": 1,
    "ppResponseCodeText": "TECHNICAL_ERROR",
    "errors": {
      "$": [
        "JSON deserialization for type '…DeleteLinkedCardRequest' was missing required properties including: 'cardLinkHash', 'saleAreaCode', 'customerCode'."
      ]
    },
    "traceId": "00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00"
  }
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Record not found.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "16ce780d-2e89-47b8-9cd2-6d0d136d9816",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "c546f06c-3674-4b55-8e0f-ce8aac66f49f",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## POST /api/order — Create an order

In order to perform a payment via Paynet API, the payment must first be registered in the Paynet system. The Create order method is used to create (register) a new payment order by transmitting the required payment details from the Partner’s system to Paynet. Upon successful registration, Paynet generates and returns a unique payment identifier (Payment ID). This Payment ID is then used to redirect the customer to the Paynet payment page, where the user can review, confirm, and complete the payment. In this model, direct server-to-server communication between the Partner and Paynet is required. Data signing is not mandatory, as authentication is handled via an authorization token.

Request body (`PaymentRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `Order` | integer (int64) | yes | The unique identifier for the order. |
| `SaleAreaCode` | string | yes | The code representing the sale area or merchant location. |
| `LinkUrlSuccess` | string | yes | The URL to redirect to upon a successful payment. |
| `LinkUrlCancel` | string | yes | The URL to redirect to if the payment is canceled. |
| `CardLinkHash` | string | no | (Optional) Linked-card hash. If CardLinkHash is provided, the full Customer object (Code, NameFirst, NameLast, email, PhoneNumber) becomes required. |
| `Customer` | object | no | Represents the customer details for a payment. |
| `Customer.Code` | string | yes | The unique code or identifier for the customer. |
| `Customer.NameFirst` | string | no | (Optional) The customer's first name. |
| `Customer.NameLast` | string | no | (Optional) The customer's last name. |
| `Customer.email` | string | no | (Optional) The customer's email address. |
| `Customer.PhoneNumber` | string | no | (Optional) The customer's phone number. If it is not sent, the customer types it on the payment page (block "Billing information"). |
| `Currency` | integer (int32) | yes | The currency code. |
| `ExpiryDate` | string (date-time) | yes | The expiration date and time for this payment request. Format YYYY-MM-DDTHH:mm:ss, Chisinau local time (Europe/Chisinau); must be in the future. |
| `Services` | array | yes | The list of services included in this payment. |
| `Services[].Name` | string | yes | The name of the service. |
| `Services[].Description` | string | yes | The description of the service. |
| `Services[].Amount` | integer (int64) | yes | The total amount for this service. |
| `Services[].Products` | array | no | (Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional. |
| `Services[].Products[].LineNo` | integer (int32) | yes | The line number or position of the product in the list. |
| `Services[].Products[].Name` | string | yes | The name of the product. |
| `Services[].Products[].Description` | string | no | (Optional) The description of the product. |
| `Services[].Products[].Code` | string | no | (Optional) Partner product code. |
| `Services[].Products[].UnitPrice` | integer (int64) | yes | The price per single unit of the product. |
| `Services[].Products[].Quantity` | integer (int64) | yes | Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs. |
| `Services[].Products[].Amount` | integer (int64) | yes | The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100). |
| `Services[].Products[].TotalAmount` | integer (int64) | yes | The final total amount including any taxes or discounts. |
| `MoneyType` | string | yes | Payment methods shown to the customer: "All" — all methods enabled for the merchant; "Card" — card (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — Paynet wallet; "MIA" — MIA instant payments; "CashInvoice" — cash invoice. Values: `All`, `Card`, `Paynet`, `MIA`, `CashInvoice`. |
| `Lang` | string | yes | UI language for payment page: RO, RU or EN; upper or lower case (EN = en). An unknown value opens the page in English. |

Request example:

```json
{
  "Order": 1762444800000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    {
      "Name": "Demo eShop",
      "Description": "Order #1762444800000",
      "Amount": 300
    }
  ],
  "MoneyType": "Card",
  "Lang": "EN"
}
```

Response `200` — Order created. Real response from the test environment for the request example (status 1 = registered, not paid yet).:

```json
{
  "paymentId": 328731,
  "paymentLink": "https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735",
  "cardLinkHash": null,
  "status": 1,
  "message": null,
  "order": 1762444800000,
  "merchantCode": "265505",
  "saleAreaCode": "onlidocumentation_md",
  "linkUrlSuccess": "https://shop.example/payment/success",
  "linkUrlCancel": "https://shop.example/payment/cancel",
  "signature": "8fa1bd0923368d3bb700fccacc263735",
  "amount": {
    "requestAmount": 300,
    "requestCurrency": 498,
    "amount": 300,
    "paidAmount": null
  },
  "customer": {
    "code": "464566161",
    "nameFirst": "First Name",
    "nameLast": "Last Name",
    "email": "customer@example.com",
    "country": null,
    "city": null,
    "address": null,
    "phoneNumber": "37360000000",
    "cardLinkHash": null
  },
  "payer": null,
  "expiryDate": "2026-12-31 23:59:59",
  "registered": "2026-11-09 18:16:41",
  "paidDate": null,
  "services": [
    {
      "name": "Demo eShop",
      "description": "Order #1762444800000",
      "amount": 300,
      "products": [
        {
          "lineNo": 1,
          "name": "Demo eShop",
          "description": "Order #1762444800000",
          "unitPrice": 300,
          "unitProduct": null,
          "quantity": 100,
          "amount": 300,
          "totalAmount": 300
        }
      ]
    }
  ],
  "moneyType": "Card"
}
```

Response `400` — Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "9b9346f9-f83a-465d-ac8d-dc382c460c22",
  "details": "The invalid parameter is: XXXX"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "c546f06c-3674-4b55-8e0f-ce8aac66f49f",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## GET /api/order/{id} — Get a payment info by payment id

The get payment info method is used to retrieve detailed information about a specific payment using its unique identifier (PaymentId). To perform this request, the Partner must provide the payment ID in the request URL. Paynet will return the current status of the payment along with all relevant details, such as amount, currency, transaction status, and associated metadata. This method allows the Partner to verify the payment status, track transaction progress, and obtain up-to-date information about a previously registered payment.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `id` | path | integer (int64) | yes | The unique identifier of the payment transaction to retrieve. |

Response `200` — Payment found. Real response from the test environment (status 1 = registered, not paid yet).:

```json
{
  "paymentId": 328731,
  "paymentLink": "https://test.paynet.md/ecom/getecom",
  "cardLinkHash": null,
  "status": 1,
  "message": null,
  "order": 1762444800000,
  "merchantCode": "265505",
  "saleAreaCode": "onlidocumentation_md",
  "linkUrlSuccess": "https://shop.example/payment/success",
  "linkUrlCancel": "https://shop.example/payment/cancel",
  "signature": null,
  "amount": {
    "requestAmount": 300,
    "requestCurrency": 498,
    "amount": 300,
    "paidAmount": null
  },
  "customer": {
    "code": "464566161",
    "nameFirst": "First Name",
    "nameLast": "Last Name",
    "email": "customer@example.com",
    "country": null,
    "city": null,
    "address": null,
    "phoneNumber": "37360000000",
    "cardLinkHash": null
  },
  "payer": null,
  "expiryDate": "2026-12-31 23:59:59",
  "registered": "2026-11-09 18:16:41",
  "paidDate": null,
  "services": [
    {
      "name": "Demo eShop",
      "description": "Order #1762444800000",
      "amount": 300,
      "products": [
        {
          "lineNo": 1,
          "name": "Demo eShop",
          "description": "Order #1762444800000",
          "unitPrice": 300,
          "unitProduct": null,
          "quantity": 100,
          "amount": 300,
          "totalAmount": 300
        }
      ]
    }
  ],
  "moneyType": "Card"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Record not found.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "e8e43475-84c2-405a-803f-eb68208f03be",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## GET /api/order/merchant/{id} — Get a payment info by merchant order id

Returns the payment registered with your order number (the `Order` value you sent when creating the payment). Use it when you do not have the Paynet paymentId, for example after a timeout during order creation. The response contains the current status, amounts, dates and payer details.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `id` | path | integer (int64) | yes | The unique order identifier provided by the merchant. |

Response `200` — Payment found. Real response from the test environment (status 1 = registered, not paid yet).:

```json
{
  "paymentId": 328731,
  "paymentLink": "https://test.paynet.md/ecom/getecom",
  "cardLinkHash": null,
  "status": 1,
  "message": null,
  "order": 1762444800000,
  "merchantCode": "265505",
  "saleAreaCode": "onlidocumentation_md",
  "linkUrlSuccess": "https://shop.example/payment/success",
  "linkUrlCancel": "https://shop.example/payment/cancel",
  "signature": null,
  "amount": {
    "requestAmount": 300,
    "requestCurrency": 498,
    "amount": 300,
    "paidAmount": null
  },
  "customer": {
    "code": "464566161",
    "nameFirst": "First Name",
    "nameLast": "Last Name",
    "email": "customer@example.com",
    "country": null,
    "city": null,
    "address": null,
    "phoneNumber": "37360000000",
    "cardLinkHash": null
  },
  "payer": null,
  "expiryDate": "2026-12-31 23:59:59",
  "registered": "2026-11-09 18:16:41",
  "paidDate": null,
  "services": [
    {
      "name": "Demo eShop",
      "description": "Order #1762444800000",
      "amount": 300,
      "products": [
        {
          "lineNo": 1,
          "name": "Demo eShop",
          "description": "Order #1762444800000",
          "unitPrice": 300,
          "unitProduct": null,
          "quantity": 100,
          "amount": 300,
          "totalAmount": 300
        }
      ]
    }
  ],
  "moneyType": "Card"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Record not found.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "e8e43475-84c2-405a-803f-eb68208f03be",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## GET /api/order/search — Get transaction list

The get transaction list method is used to retrieve a list of payments within a specified date and time interval. To perform this request, the Partner must provide the from and to parameters in the query string, defining the start and end of the search period. Paynet will return a collection of transactions that were created or processed within the specified timeframe. Each transaction record includes relevant details such as payment ID, amount, currency, status, and timestamps. This method allows the Partner to perform transaction monitoring, reporting, and reconciliation over a defined period.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `from` | query | string (date-time) | yes | Start of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored). |
| `to` | query | string (date-time) | yes | End of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored). |

Response `200` — Payments found for the period.:

Response `400` — One or more entered parameters are incorrect.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "9697f2c8-b1c2-490a-84b3-8adda9bc22e9",
  "details": "The invalid parameter is: dateStart | dateFinish"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## POST /api/order/refund — Refund a payment

The refund method is used to return funds for a previously completed payment. To perform a refund, the Partner must send the original PaymentId, refund amount, currency, sale area code, refund type, and the reason for the refund. The refund can be processed as either a full refund or a partial refund, depending on the RefundType and the amount provided in the request. After the refund request is processed, Paynet returns the result of the operation, allowing the Partner to confirm whether the refund was successfully registered and executed in the Paynet system.

Request body (`RefundRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `PaymentId` | integer (int64) | yes | The unique internal identifier of the original payment transaction to be refunded. |
| `SaleAreaCode` | string | yes | The code identifying the specific sale area or point of sale where the original transaction occurred. |
| `RefundType` | string | yes | The type of refund: "full" or "partial". Values: `full`, `partial`. |
| `Amount` | integer (int64) | yes | The exact amount to be refunded. |
| `Currency` | integer (int32) | yes | The numeric ISO code of the currency for the refund amount. |
| `Reason` | string | yes | A descriptive reason or justification for processing the refund. |

Request example:

```json
{
  "PaymentId": 328733,
  "Amount": 400,
  "SaleAreaCode": "onlidocumentation_md",
  "Currency": 498,
  "RefundType": "full",
  "Reason": "Was customer error!"
}
```

Response `200` — Refund done. Real response from the test environment. eventDate uses the format dd.MM.yyyy HH:mm:ss.:

```json
{
  "paymentId": 328733,
  "saleAreaCode": "onlidocumentation_md",
  "customer": "464566161",
  "eventDate": "09.11.2026 18:17:54",
  "refundType": "full",
  "currency": 498,
  "amount": 400,
  "merchant": "265505",
  "cardMask": "411111******1111",
  "cardLinkHash": null,
  "moneyType": "CYBER_SOURCE"
}
```

Response `400` — Invalid refund: amount above the paid amount, or another refund of the same payment. details names RefundType.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "e353a049-9eca-44e9-bc17-e5c4816320da",
  "details": "The invalid parameter is: RefundType"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Payment not found or not paid.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "72f97a7d-3a42-4c5f-9d8e-e98ee2aaa9ac",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## GET /api/statement — Get statement

Retrieves a list of payment transactions for a specified period based on the provided start and end dates. Used for generating statements and transaction reporting.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `dateStart` | query | string (date-time) | yes | The starting date of the statement period. |
| `dateFinish` | query | string (date-time) | yes | The ending date of the statement period. |
| `accountId` | query | integer (int32) | no | (Optional) The specific account identifier to filter the statement. |

Response `200` — Statement for the period.:

```json
{
  "statementDaily": [],
  "totals": {
    "startBalance": 180000,
    "totalDebit": 0,
    "totalCredit": 0,
    "finalBalance": 180000
  }
}
```

Response `400` — One or more entered parameters are incorrect.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "9697f2c8-b1c2-490a-84b3-8adda9bc22e9",
  "details": "The invalid parameter is: dateStart | dateFinish"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## GET /api/statement/download — Download statement

Generates the merchant statement for the period from dateStart to dateFinish and returns it as an Excel (.xlsx) file. The period must not exceed 31 days.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `dateStart` | query | string (date-time) | yes | The starting date of the report period. |
| `dateFinish` | query | string (date-time) | yes | The ending date of the report period (must be within 31 days of the start date). |

Response `200` — Statement as an .xlsx file.:

Response `400` — Invalid request parameters.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "cf5573ee-4749-4190-8a1a-881ee53e7c0a",
  "details": "The invalid parameter is: dateStart | dateFinish"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:

## POST /auth — Authentication and authorization

To access the Paynet service and complete authorization, you need to obtain an authorization token. You can get this token by calling the service method described below and providing the parameters (username and password) received during partner registration.

Request body (`AuthRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `grantType` | string | yes | The authorization grant type (e.g., "password"). |
| `username` | string | yes | The user's username. |
| `password` | string | yes | The user's password in plain text. |

Request example:

```json
{
  "grantType": "password",
  "username": "771064",
  "password": "sLgMnGWJ"
}
```

Response `200` — Success executed authentication.:

```json
{
  "access_token": "Ccxl7QQiMEoakkrUoiUn8PIgcmSN2ouP3XNjSmgqUH-Dn8UDg0...........",
  "token_type": "bearer",
  "expires_in": 14399
}
```

Response `401` — Wrong username or password.:

```json
{
  "status": 401,
  "message": "Wrong credentials",
  "code": "AUTHENTICATION_FAILED",
  "traceId": "8d489156-7b1c-4bfb-b88b-7a946c1b862e",
  "details": null
}
```

Response `default` — Error:

## Schemas

### AuthRequest

The authentication request model.

| Field | Type | Required | Description |
|---|---|---|---|
| `grantType` | string | yes | The authorization grant type (e.g., "password"). |
| `username` | string | yes | The user's username. |
| `password` | string | yes | The user's password in plain text. |

### Customer

Represents the customer details for a payment.

| Field | Type | Required | Description |
|---|---|---|---|
| `Code` | string | yes | The unique code or identifier for the customer. |
| `NameFirst` | string | no | (Optional) The customer's first name. |
| `NameLast` | string | no | (Optional) The customer's last name. |
| `email` | string | no | (Optional) The customer's email address. |
| `PhoneNumber` | string | no | (Optional) The customer's phone number. If it is not sent, the customer types it on the payment page (block "Billing information"). |

### DeleteLinkedCardRequest

Represents the payload required to unlink a saved payment card.

| Field | Type | Required | Description |
|---|---|---|---|
| `CardLinkHash` | string | yes | The unique hash identifying the specific card to be unlinked. |
| `SaleAreaCode` | string | yes | The code identifying the specific sale area or merchant environment. |
| `CustomerCode` | string | yes | The unique identifier or code of the customer who owns the linked card. |

### ErrorModel

Represents a standardized error response returned by the API.

| Field | Type | Required | Description |
|---|---|---|---|
| `status` | integer (int32) | no | Gets or sets the HTTP status code associated with the error (e.g., 400, 401, 500). |
| `message` | string | yes | Gets or sets a human-readable, descriptive error message intended for the client. |
| `code` | string | yes | Gets or sets the internal business logic error code or its string representation. |
| `traceId` | string | no | Gets or sets an optional unique identifier used for request tracing and debugging in the logs. |
| `details` | string | no | Gets or sets optional technical details or additional context regarding the error (e.g., specific validation failures). |

### PaymentRequest

Represents the payload for initiating a payment request. Fields not marked as required are optional.

| Field | Type | Required | Description |
|---|---|---|---|
| `Order` | integer (int64) | yes | The unique identifier for the order. |
| `SaleAreaCode` | string | yes | The code representing the sale area or merchant location. |
| `LinkUrlSuccess` | string | yes | The URL to redirect to upon a successful payment. |
| `LinkUrlCancel` | string | yes | The URL to redirect to if the payment is canceled. |
| `CardLinkHash` | string | no | (Optional) Linked-card hash. If CardLinkHash is provided, the full Customer object (Code, NameFirst, NameLast, email, PhoneNumber) becomes required. |
| `Customer` | object | no | Represents the customer details for a payment. |
| `Customer.Code` | string | yes | The unique code or identifier for the customer. |
| `Customer.NameFirst` | string | no | (Optional) The customer's first name. |
| `Customer.NameLast` | string | no | (Optional) The customer's last name. |
| `Customer.email` | string | no | (Optional) The customer's email address. |
| `Customer.PhoneNumber` | string | no | (Optional) The customer's phone number. If it is not sent, the customer types it on the payment page (block "Billing information"). |
| `Currency` | integer (int32) | yes | The currency code. |
| `ExpiryDate` | string (date-time) | yes | The expiration date and time for this payment request. Format YYYY-MM-DDTHH:mm:ss, Chisinau local time (Europe/Chisinau); must be in the future. |
| `Services` | array | yes | The list of services included in this payment. |
| `Services[].Name` | string | yes | The name of the service. |
| `Services[].Description` | string | yes | The description of the service. |
| `Services[].Amount` | integer (int64) | yes | The total amount for this service. |
| `Services[].Products` | array | no | (Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional. |
| `Services[].Products[].LineNo` | integer (int32) | yes | The line number or position of the product in the list. |
| `Services[].Products[].Name` | string | yes | The name of the product. |
| `Services[].Products[].Description` | string | no | (Optional) The description of the product. |
| `Services[].Products[].Code` | string | no | (Optional) Partner product code. |
| `Services[].Products[].UnitPrice` | integer (int64) | yes | The price per single unit of the product. |
| `Services[].Products[].Quantity` | integer (int64) | yes | Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs. |
| `Services[].Products[].Amount` | integer (int64) | yes | The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100). |
| `Services[].Products[].TotalAmount` | integer (int64) | yes | The final total amount including any taxes or discounts. |
| `MoneyType` | string | yes | Payment methods shown to the customer: "All" — all methods enabled for the merchant; "Card" — card (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — Paynet wallet; "MIA" — MIA instant payments; "CashInvoice" — cash invoice. Values: `All`, `Card`, `Paynet`, `MIA`, `CashInvoice`. |
| `Lang` | string | yes | UI language for payment page: RO, RU or EN; upper or lower case (EN = en). An unknown value opens the page in English. |

### Product

Represents a single product item within a service.

| Field | Type | Required | Description |
|---|---|---|---|
| `LineNo` | integer (int32) | yes | The line number or position of the product in the list. |
| `Name` | string | yes | The name of the product. |
| `Description` | string | no | (Optional) The description of the product. |
| `Code` | string | no | (Optional) Partner product code. |
| `UnitPrice` | integer (int64) | yes | The price per single unit of the product. |
| `Quantity` | integer (int64) | yes | Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs. |
| `Amount` | integer (int64) | yes | The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100). |
| `TotalAmount` | integer (int64) | yes | The final total amount including any taxes or discounts. |

### RefundRequest

Represents the payload required to initiate a refund for a specific payment transaction.

| Field | Type | Required | Description |
|---|---|---|---|
| `PaymentId` | integer (int64) | yes | The unique internal identifier of the original payment transaction to be refunded. |
| `SaleAreaCode` | string | yes | The code identifying the specific sale area or point of sale where the original transaction occurred. |
| `RefundType` | string | yes | The type of refund: "full" or "partial". Values: `full`, `partial`. |
| `Amount` | integer (int64) | yes | The exact amount to be refunded. |
| `Currency` | integer (int32) | yes | The numeric ISO code of the currency for the refund amount. |
| `Reason` | string | yes | A descriptive reason or justification for processing the refund. |

### Service

Represents a service included in the payment request.

| Field | Type | Required | Description |
|---|---|---|---|
| `Name` | string | yes | The name of the service. |
| `Description` | string | yes | The description of the service. |
| `Amount` | integer (int64) | yes | The total amount for this service. |
| `Products` | array | no | (Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional. |
| `Products[].LineNo` | integer (int32) | yes | The line number or position of the product in the list. |
| `Products[].Name` | string | yes | The name of the product. |
| `Products[].Description` | string | no | (Optional) The description of the product. |
| `Products[].Code` | string | no | (Optional) Partner product code. |
| `Products[].UnitPrice` | integer (int64) | yes | The price per single unit of the product. |
| `Products[].Quantity` | integer (int64) | yes | Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs. |
| `Products[].Amount` | integer (int64) | yes | The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100). |
| `Products[].TotalAmount` | integer (int64) | yes | The final total amount including any taxes or discounts. |

### AuthResponse

Successful authentication response.

| Field | Type | Required | Description |
|---|---|---|---|
| `access_token` | string | no | Bearer token for the Authorization header. |
| `token_type` | string | no | Always "bearer". |
| `expires_in` | integer | no | Token lifetime in seconds (about 4 hours). |

### PaymentResponse

Payment object returned by create/get endpoints.

| Field | Type | Required | Description |
|---|---|---|---|
| `paymentId` | integer (int64) | no | Paynet payment ID. Store it with your order. |
| `paymentLink` | string | no | URL of the Paynet payment page. Redirect the customer here. |
| `cardLinkHash` | string | no | Saved card hash (linked-card scenarios). |
| `status` | integer | no | Payment status code. A new order has status 1. |
| `message` | string | no |  |
| `order` | integer (int64) | no | Your order number (Order). |
| `merchantCode` | string | no |  |
| `saleAreaCode` | string | no |  |
| `linkUrlSuccess` | string | no | Return URL after a successful payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment). |
| `linkUrlCancel` | string | no | Return URL after a failed or cancelled payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment). |
| `signature` | string | no | Internal value of the payment link (equals the s parameter of paymentLink); null in GET responses. Not a signature to verify. |
| `amount` | object | no |  |
| `amount.requestAmount` | integer | no |  |
| `amount.requestCurrency` | integer | no |  |
| `amount.amount` | integer | no |  |
| `amount.paidAmount` | integer | no | Amount actually paid, minor units; null until the payment is paid. |
| `customer` | object | no |  |
| `customer.code` | string | no |  |
| `customer.nameFirst` | string | no |  |
| `customer.nameLast` | string | no |  |
| `customer.email` | string | no |  |
| `customer.country` | string | no |  |
| `customer.city` | string | no |  |
| `customer.address` | string | no |  |
| `customer.phoneNumber` | string | no |  |
| `customer.cardLinkHash` | string | no |  |
| `payer` | object | no | Payer details after payment. |
| `payer.cardMask` | string | no |  |
| `payer.rrn` | string | no |  |
| `payer.cardExpireMonth` | string | no |  |
| `payer.cardExpireYear` | string | no |  |
| `payer.cardIssuer` | string | no |  |
| `payer.cardLinkHash` | string | no |  |
| `payer.moneyType` | string | no |  |
| `payer.payerName` | string | no |  |
| `payer.payerSurname` | string | no |  |
| `payer.payerIDNP` | string | no |  |
| `expiryDate` | string | no | Format "YYYY-MM-DD HH:mm:ss". |
| `registered` | string | no |  |
| `paidDate` | string | no | Set when the payment is paid. |
| `services` | array | no |  |
| `moneyType` | string | no |  |

### ErrorModelUnauthorized

401 for a missing, invalid or expired Bearer token. Note the capitalised keys.

| Field | Type | Required | Description |
|---|---|---|---|
| `Status` | integer | yes |  |
| `Message` | string | yes |  |
| `Code` | string | yes |  |
| `TraceId` | string | no |  |

### ErrorInfoResponse

400 when the request body cannot be read (invalid JSON, wrong types, missing required fields).

| Field | Type | Required | Description |
|---|---|---|---|
| `errorInfo` | object | yes |  |
| `errorInfo.type` | string | no |  |
| `errorInfo.title` | string | no |  |
| `errorInfo.status` | integer | no |  |
| `errorInfo.detail` | string | no |  |
| `errorInfo.instance` | string | no |  |
| `errorInfo.ppResponseCodeEnum` | string | no |  |
| `errorInfo.ppResponseCode` | integer | no |  |
| `errorInfo.ppResponseCodeText` | string | no |  |
| `errorInfo.errors` | object | no | Problem fields and messages. |
| `errorInfo.traceId` | string | no |  |
| `errorInfo.ppResponseCodeDescription` | string | no |  |

### RefundResponse

Refund result (immediate; no notification is sent).

| Field | Type | Required | Description |
|---|---|---|---|
| `paymentId` | integer (int64) | no |  |
| `saleAreaCode` | string | no |  |
| `customer` | string | no |  |
| `eventDate` | string | no | Format DD.MM.YYYY HH:mm:ss |
| `refundType` | string | no |  |
| `currency` | integer | no |  |
| `amount` | integer | no |  |
| `merchant` | string | no |  |
| `cardMask` | string | no |  |
| `cardLinkHash` | string | no |  |
| `moneyType` | string | no | Processing code, e.g. CYBER_SOURCE (not the notification MoneyType). |

### PaymentSearchResponse

| Field | Type | Required | Description |
|---|---|---|---|
| `payments` | array | no |  |
| `payments[].paymentId` | integer (int64) | no | Paynet payment ID. Store it with your order. |
| `payments[].paymentLink` | string | no | URL of the Paynet payment page. Redirect the customer here. |
| `payments[].cardLinkHash` | string | no | Saved card hash (linked-card scenarios). |
| `payments[].status` | integer | no | Payment status code. A new order has status 1. |
| `payments[].message` | string | no |  |
| `payments[].order` | integer (int64) | no | Your order number (Order). |
| `payments[].merchantCode` | string | no |  |
| `payments[].saleAreaCode` | string | no |  |
| `payments[].linkUrlSuccess` | string | no | Return URL after a successful payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment). |
| `payments[].linkUrlCancel` | string | no | Return URL after a failed or cancelled payment, as sent in the order. Can be null in GET /api/order/search results (seen on the test environment). |
| `payments[].signature` | string | no | Internal value of the payment link (equals the s parameter of paymentLink); null in GET responses. Not a signature to verify. |
| `payments[].amount` | object | no |  |
| `payments[].amount.requestAmount` | integer | no |  |
| `payments[].amount.requestCurrency` | integer | no |  |
| `payments[].amount.amount` | integer | no |  |
| `payments[].amount.paidAmount` | integer | no | Amount actually paid, minor units; null until the payment is paid. |
| `payments[].customer` | object | no |  |
| `payments[].customer.code` | string | no |  |
| `payments[].customer.nameFirst` | string | no |  |
| `payments[].customer.nameLast` | string | no |  |
| `payments[].customer.email` | string | no |  |
| `payments[].customer.country` | string | no |  |
| `payments[].customer.city` | string | no |  |
| `payments[].customer.address` | string | no |  |
| `payments[].customer.phoneNumber` | string | no |  |
| `payments[].customer.cardLinkHash` | string | no |  |
| `payments[].payer` | object | no | Payer details after payment. |
| `payments[].payer.cardMask` | string | no |  |
| `payments[].payer.rrn` | string | no |  |
| `payments[].payer.cardExpireMonth` | string | no |  |
| `payments[].payer.cardExpireYear` | string | no |  |
| `payments[].payer.cardIssuer` | string | no |  |
| `payments[].payer.cardLinkHash` | string | no |  |
| `payments[].payer.moneyType` | string | no |  |
| `payments[].payer.payerName` | string | no |  |
| `payments[].payer.payerSurname` | string | no |  |
| `payments[].payer.payerIDNP` | string | no |  |
| `payments[].expiryDate` | string | no | Format "YYYY-MM-DD HH:mm:ss". |
| `payments[].registered` | string | no |  |
| `payments[].paidDate` | string | no | Set when the payment is paid. |
| `payments[].services` | array | no |  |
| `payments[].moneyType` | string | no |  |

### StatementResponse

| Field | Type | Required | Description |
|---|---|---|---|
| `statementDaily` | array | no |  |
| `totals` | object | no |  |
| `totals.startBalance` | integer | no |  |
| `totals.totalDebit` | integer | no |  |
| `totals.totalCredit` | integer | no |  |
| `totals.finalBalance` | integer | no |  |
