# GET /api/order/{id} — Get a payment info by payment id

The get payment info method is used to retrieve detailed information about a specific payment using its unique identifier (PaymentId). To perform this request, the Partner must provide the payment ID in the request URL. Paynet will return the current status of the payment along with all relevant details, such as amount, currency, transaction status, and associated metadata. This method allows the Partner to verify the payment status, track transaction progress, and obtain up-to-date information about a previously registered payment.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `id` | path | integer (int64) | yes | The unique identifier of the payment transaction to retrieve. |

Response `200` — Payment found. Real response from the test environment (status 1 = registered, not paid yet).:

```json
{
  "paymentId": 328731,
  "paymentLink": "https://test.paynet.md/ecom/getecom",
  "cardLinkHash": null,
  "status": 1,
  "message": null,
  "order": 1762444800000,
  "merchantCode": "265505",
  "saleAreaCode": "onlidocumentation_md",
  "linkUrlSuccess": "https://shop.example/payment/success",
  "linkUrlCancel": "https://shop.example/payment/cancel",
  "signature": null,
  "amount": {
    "requestAmount": 300,
    "requestCurrency": 498,
    "amount": 300,
    "paidAmount": null
  },
  "customer": {
    "code": "464566161",
    "nameFirst": "First Name",
    "nameLast": "Last Name",
    "email": "customer@example.com",
    "country": null,
    "city": null,
    "address": null,
    "phoneNumber": "37360000000",
    "cardLinkHash": null
  },
  "payer": null,
  "expiryDate": "2026-12-31 23:59:59",
  "registered": "2026-11-09 18:16:41",
  "paidDate": null,
  "services": [
    {
      "name": "Demo eShop",
      "description": "Order #1762444800000",
      "amount": 300,
      "products": [
        {
          "lineNo": 1,
          "name": "Demo eShop",
          "description": "Order #1762444800000",
          "unitPrice": 300,
          "unitProduct": null,
          "quantity": 100,
          "amount": 300,
          "totalAmount": 300
        }
      ]
    }
  ],
  "moneyType": "Card"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Record not found.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "e8e43475-84c2-405a-803f-eb68208f03be",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
