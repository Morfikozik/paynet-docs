# GET /api/order/search — Get transaction list

The get transaction list method is used to retrieve a list of payments within a specified date and time interval. To perform this request, the Partner must provide the from and to parameters in the query string, defining the start and end of the search period. Paynet will return a collection of transactions that were created or processed within the specified timeframe. Each transaction record includes relevant details such as payment ID, amount, currency, status, and timestamps. This method allows the Partner to perform transaction monitoring, reporting, and reconciliation over a defined period.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `from` | query | string (date-time) | yes | Start of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored). |
| `to` | query | string (date-time) | yes | End of the search period in Chișinău local time, YYYY-MM-DDTHH:mm:ss (a trailing Z is ignored). |

Response `200` — Payments found for the period.:

Response `400` — One or more entered parameters are incorrect.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "9697f2c8-b1c2-490a-84b3-8adda9bc22e9",
  "details": "The invalid parameter is: dateStart | dateFinish"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
