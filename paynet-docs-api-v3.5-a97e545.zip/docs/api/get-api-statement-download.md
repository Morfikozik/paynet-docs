# GET /api/statement/download — Download statement

Generates the merchant statement for the period from dateStart to dateFinish and returns it as an Excel (.xlsx) file. The period must not exceed 31 days.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `dateStart` | query | string (date-time) | yes | The starting date of the report period. |
| `dateFinish` | query | string (date-time) | yes | The ending date of the report period (must be within 31 days of the start date). |

Response `200` — Statement as an .xlsx file.:

Response `400` — Invalid request parameters.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "cf5573ee-4749-4190-8a1a-881ee53e7c0a",
  "details": "The invalid parameter is: dateStart | dateFinish"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
