# GET /api/statement — Get statement

Retrieves a list of payment transactions for a specified period based on the provided start and end dates. Used for generating statements and transaction reporting.

| Parameter | In | Type | Required | Description |
|---|---|---|---|---|
| `dateStart` | query | string (date-time) | yes | The starting date of the statement period. |
| `dateFinish` | query | string (date-time) | yes | The ending date of the statement period. |
| `accountId` | query | integer (int32) | no | (Optional) The specific account identifier to filter the statement. |

Response `200` — Statement for the period.:

```json
{
  "statementDaily": [],
  "totals": {
    "startBalance": 180000,
    "totalDebit": 0,
    "totalCredit": 0,
    "finalBalance": 180000
  }
}
```

Response `400` — One or more entered parameters are incorrect.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "9697f2c8-b1c2-490a-84b3-8adda9bc22e9",
  "details": "The invalid parameter is: dateStart | dateFinish"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
