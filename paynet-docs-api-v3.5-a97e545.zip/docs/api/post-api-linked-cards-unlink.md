# POST /api/linked-cards/unlink — Delete linked card

The delete linked card method is used to deactivate and remove a previously linked card from the Paynet system. When this method is executed, the specified card token is permanently invalidated, and the card is unlinked from the customer account. As a result, the token can no longer be used for any payment operations, including recurring or one-click payments. To perform this request, the Partner must provide the unique card identifier (CardLinkHash), the corresponding SaleAreaCode, and the CustomerCode associated with the card. This method ensures that sensitive payment credentials are securely removed and prevents any further unauthorized or unintended use.

Request body (`DeleteLinkedCardRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `CardLinkHash` | string | yes | The unique hash identifying the specific card to be unlinked. |
| `SaleAreaCode` | string | yes | The code identifying the specific sale area or merchant environment. |
| `CustomerCode` | string | yes | The unique identifier or code of the customer who owns the linked card. |

Request example:

```json
{
  "CardLinkHash": "1037153_b3f50103610e4fe9948ff8db553151f3",
  "SaleAreaCode": "onlidocumentation_md",
  "CustomerCode": "customer_code"
}
```

Response `200` — Success executed unlink card.:

```json
{
  "responseCode": "SUCCESS"
}
```

Response `400` — Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.:

```json
{
  "errorInfo": {
    "type": "https://tools.ietf.org/html/rfc9110#section-15.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "detail": null,
    "instance": null,
    "ppResponseCodeEnum": "TECHNICAL_ERROR",
    "ppResponseCode": 1,
    "ppResponseCodeText": "TECHNICAL_ERROR",
    "errors": {
      "$": [
        "JSON deserialization for type '…DeleteLinkedCardRequest' was missing required properties including: 'cardLinkHash', 'saleAreaCode', 'customerCode'."
      ]
    },
    "traceId": "00-7c209d88f31e3e5cd2f7bd88ae2f23c2-ad167338e418068c-00"
  }
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Record not found.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "16ce780d-2e89-47b8-9cd2-6d0d136d9816",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "c546f06c-3674-4b55-8e0f-ce8aac66f49f",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
