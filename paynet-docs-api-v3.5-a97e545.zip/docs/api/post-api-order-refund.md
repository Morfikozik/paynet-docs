# POST /api/order/refund — Refund a payment

The refund method is used to return funds for a previously completed payment. To perform a refund, the Partner must send the original PaymentId, refund amount, currency, sale area code, refund type, and the reason for the refund. The refund can be processed as either a full refund or a partial refund, depending on the RefundType and the amount provided in the request. After the refund request is processed, Paynet returns the result of the operation, allowing the Partner to confirm whether the refund was successfully registered and executed in the Paynet system.

Request body (`RefundRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `PaymentId` | integer (int64) | yes | The unique internal identifier of the original payment transaction to be refunded. |
| `SaleAreaCode` | string | yes | The code identifying the specific sale area or point of sale where the original transaction occurred. |
| `RefundType` | string | yes | The type of refund: "full" or "partial". Values: `full`, `partial`. |
| `Amount` | integer (int64) | yes | The exact amount to be refunded. |
| `Currency` | integer (int32) | yes | The numeric ISO code of the currency for the refund amount. |
| `Reason` | string | yes | A descriptive reason or justification for processing the refund. |

Request example:

```json
{
  "PaymentId": 328733,
  "Amount": 400,
  "SaleAreaCode": "onlidocumentation_md",
  "Currency": 498,
  "RefundType": "full",
  "Reason": "Was customer error!"
}
```

Response `200` — Refund done. Real response from the test environment. eventDate uses the format dd.MM.yyyy HH:mm:ss.:

```json
{
  "paymentId": 328733,
  "saleAreaCode": "onlidocumentation_md",
  "customer": "464566161",
  "eventDate": "09.11.2026 18:17:54",
  "refundType": "full",
  "currency": 498,
  "amount": 400,
  "merchant": "265505",
  "cardMask": "411111******1111",
  "cardLinkHash": null,
  "moneyType": "CYBER_SOURCE"
}
```

Response `400` — Invalid refund: amount above the paid amount, or another refund of the same payment. details names RefundType.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "e353a049-9eca-44e9-bc17-e5c4816320da",
  "details": "The invalid parameter is: RefundType"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `404` — Payment not found or not paid.:

```json
{
  "status": 404,
  "message": "Record not found",
  "code": "NOT_FOUND_RECORD",
  "traceId": "72f97a7d-3a42-4c5f-9d8e-e98ee2aaa9ac",
  "details": "No records were found for the provided data"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "6bc2b683-e796-43ae-9775-6d9f116675a6",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
