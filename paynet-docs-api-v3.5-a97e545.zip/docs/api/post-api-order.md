# POST /api/order — Create an order

In order to perform a payment via Paynet API, the payment must first be registered in the Paynet system. The Create order method is used to create (register) a new payment order by transmitting the required payment details from the Partner’s system to Paynet. Upon successful registration, Paynet generates and returns a unique payment identifier (Payment ID). This Payment ID is then used to redirect the customer to the Paynet payment page, where the user can review, confirm, and complete the payment. In this model, direct server-to-server communication between the Partner and Paynet is required. Data signing is not mandatory, as authentication is handled via an authorization token.

Request body (`PaymentRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `Order` | integer (int64) | yes | The unique identifier for the order. |
| `SaleAreaCode` | string | yes | The code representing the sale area or merchant location. |
| `LinkUrlSuccess` | string | yes | The URL to redirect to upon a successful payment. |
| `LinkUrlCancel` | string | yes | The URL to redirect to if the payment is canceled. |
| `CardLinkHash` | string | no | (Optional) Linked-card hash. If CardLinkHash is provided, the full Customer object (Code, NameFirst, NameLast, email, PhoneNumber) becomes required. |
| `Customer` | object | no | Represents the customer details for a payment. |
| `Customer.Code` | string | yes | The unique code or identifier for the customer. |
| `Customer.NameFirst` | string | no | (Optional) The customer's first name. |
| `Customer.NameLast` | string | no | (Optional) The customer's last name. |
| `Customer.email` | string | no | (Optional) The customer's email address. |
| `Customer.PhoneNumber` | string | no | (Optional) The customer's phone number. If it is not sent, the customer types it on the payment page (block "Billing information"). |
| `Currency` | integer (int32) | yes | The currency code. |
| `ExpiryDate` | string (date-time) | yes | The expiration date and time for this payment request. Format YYYY-MM-DDTHH:mm:ss, Chisinau local time (Europe/Chisinau); must be in the future. |
| `Services` | array | yes | The list of services included in this payment. |
| `Services[].Name` | string | yes | The name of the service. |
| `Services[].Description` | string | yes | The description of the service. |
| `Services[].Amount` | integer (int64) | yes | The total amount for this service. |
| `Services[].Products` | array | no | (Optional) A list of specific products under this service. If you send products, LineNo, Name, UnitPrice, Quantity, Amount and TotalAmount are required; Code and Description are optional. |
| `Services[].Products[].LineNo` | integer (int32) | yes | The line number or position of the product in the list. |
| `Services[].Products[].Name` | string | yes | The name of the product. |
| `Services[].Products[].Description` | string | no | (Optional) The description of the product. |
| `Services[].Products[].Code` | string | no | (Optional) Partner product code. |
| `Services[].Products[].UnitPrice` | integer (int64) | yes | The price per single unit of the product. |
| `Services[].Products[].Quantity` | integer (int64) | yes | Quantity in hundredths: 100 = 1 pc, 300 = 3 pcs. |
| `Services[].Products[].Amount` | integer (int64) | yes | The total amount for this quantity in minor units (usually UnitPrice * Quantity / 100). |
| `Services[].Products[].TotalAmount` | integer (int64) | yes | The final total amount including any taxes or discounts. |
| `MoneyType` | string | yes | Payment methods shown to the customer: "All" — all methods enabled for the merchant; "Card" — card (Visa/Mastercard), Apple Pay, Google Pay; "Paynet" — Paynet wallet; "MIA" — MIA instant payments; "CashInvoice" — cash invoice. Values: `All`, `Card`, `Paynet`, `MIA`, `CashInvoice`. |
| `Lang` | string | yes | UI language for payment page: RO, RU or EN; upper or lower case (EN = en). An unknown value opens the page in English. |

Request example:

```json
{
  "Order": 1762444800000,
  "SaleAreaCode": "onlidocumentation_md",
  "LinkUrlSuccess": "https://shop.example/payment/success",
  "LinkUrlCancel": "https://shop.example/payment/cancel",
  "Customer": {
    "Code": "464566161",
    "NameFirst": "First Name",
    "NameLast": "Last Name",
    "email": "customer@example.com",
    "PhoneNumber": "37360000000"
  },
  "Currency": 498,
  "ExpiryDate": "2026-12-31T23:59:59",
  "Services": [
    {
      "Name": "Demo eShop",
      "Description": "Order #1762444800000",
      "Amount": 300
    }
  ],
  "MoneyType": "Card",
  "Lang": "EN"
}
```

Response `200` — Order created. Real response from the test environment for the request example (status 1 = registered, not paid yet).:

```json
{
  "paymentId": 328731,
  "paymentLink": "https://test.paynet.md/ecom/getecom/328731?s=8fa1bd0923368d3bb700fccacc263735",
  "cardLinkHash": null,
  "status": 1,
  "message": null,
  "order": 1762444800000,
  "merchantCode": "265505",
  "saleAreaCode": "onlidocumentation_md",
  "linkUrlSuccess": "https://shop.example/payment/success",
  "linkUrlCancel": "https://shop.example/payment/cancel",
  "signature": "8fa1bd0923368d3bb700fccacc263735",
  "amount": {
    "requestAmount": 300,
    "requestCurrency": 498,
    "amount": 300,
    "paidAmount": null
  },
  "customer": {
    "code": "464566161",
    "nameFirst": "First Name",
    "nameLast": "Last Name",
    "email": "customer@example.com",
    "country": null,
    "city": null,
    "address": null,
    "phoneNumber": "37360000000",
    "cardLinkHash": null
  },
  "payer": null,
  "expiryDate": "2026-12-31 23:59:59",
  "registered": "2026-11-09 18:16:41",
  "paidDate": null,
  "services": [
    {
      "name": "Demo eShop",
      "description": "Order #1762444800000",
      "amount": 300,
      "products": [
        {
          "lineNo": 1,
          "name": "Demo eShop",
          "description": "Order #1762444800000",
          "unitPrice": 300,
          "unitProduct": null,
          "quantity": 100,
          "amount": 300,
          "totalAmount": 300
        }
      ]
    }
  ],
  "moneyType": "Card"
}
```

Response `400` — Invalid request. Either the usual error body or, when the body cannot be read, an errorInfo object.:

```json
{
  "status": 400,
  "message": "One or more entered parameters are incorrect.",
  "code": "INVALID_PARAMETER",
  "traceId": "9b9346f9-f83a-465d-ac8d-dc382c460c22",
  "details": "The invalid parameter is: XXXX"
}
```

Response `401` — Bearer token missing, invalid or expired. Keys are capitalised.:

```json
{
  "Status": 401,
  "Message": "Access denied. The Bearer token is missing, invalid, or has expired.",
  "Code": "UNAUTHORIZED",
  "TraceId": "b4480a88-5942-455c-99ac-68d3547aaccb"
}
```

Response `500` — Internal server error occurred while processing the request.:

```json
{
  "status": 500,
  "message": "One or more errors occurred.",
  "code": "TECHNICAL_ERROR",
  "traceId": "c546f06c-3674-4b55-8e0f-ce8aac66f49f",
  "details": "Please verify the transmitted data and try again, or contact support."
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
