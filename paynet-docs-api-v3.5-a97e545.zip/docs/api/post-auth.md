# POST /auth — Authentication and authorization

To access the Paynet service and complete authorization, you need to obtain an authorization token. You can get this token by calling the service method described below and providing the parameters (username and password) received during partner registration.

Request body (`AuthRequest`):

| Field | Type | Required | Description |
|---|---|---|---|
| `grantType` | string | yes | The authorization grant type (e.g., "password"). |
| `username` | string | yes | The user's username. |
| `password` | string | yes | The user's password in plain text. |

Request example:

```json
{
  "grantType": "password",
  "username": "771064",
  "password": "sLgMnGWJ"
}
```

Response `200` — Success executed authentication.:

```json
{
  "access_token": "Ccxl7QQiMEoakkrUoiUn8PIgcmSN2ouP3XNjSmgqUH-Dn8UDg0...........",
  "token_type": "bearer",
  "expires_in": 14399
}
```

Response `401` — Wrong username or password.:

```json
{
  "status": 401,
  "message": "Wrong credentials",
  "code": "AUTHENTICATION_FAILED",
  "traceId": "8d489156-7b1c-4bfb-b88b-7a946c1b862e",
  "details": null
}
```

Response `default` — Error:


---

Base URL: test `https://ecom-api-test.paynet.md`, production `https://ecom-api.paynet.md` (same paths). All endpoints except `/auth` require `Authorization: Bearer <access_token>`.

Full API reference with all schemas: https://docs.paynet.md/api/docs/api-reference.md. Complete documentation: https://docs.paynet.md/api/llms-full.txt.
