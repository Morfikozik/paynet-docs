# Testare

## Mediul de test

| Element | Valoare |
|---|---|
| URL de bază API | `https://ecom-api-test.paynet.md` |
| URL-ul formularului hosted checkout | `https://test.paynet.md/ecom/checkout` |
| Utilizator / parolă API | `771064` / `sLgMnGWJ` |
| Codul comerciantului | `265505` |
| Codul zonei de vânzare | `onlidocumentation_md` |
| Cheia secretă pentru semnătura hosted checkout | `F90D6485-9CCC-458B-96A3-8958AF9B4458` |
| Cheia secretă pentru notificări | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` |

Aceste date sunt comune pentru toți cei care testează pe portal: plățile de test ale altora apar în căutări și extrase. Dacă aveți nevoie de un mediu izolat, cereți de la Paynet un comerciant de test propriu.

## Card de test

| Card | Expirare | CVV | Rezultat |
|---|---|---|---|
| Visa `4111 1111 1111 1111` | `12/27` | `777` | plată reușită |

Cardurile de test pot reproduce doar o plată reușită: nu există carduri pentru plăți refuzate sau 3-D Secure. Tratarea refuzului trebuie totuși implementată și testată cu răspunsuri API simulate: `status` = `5` și revenirea clientului la `LinkUrlCancel` (vezi [Plată eșuată](https://docs.paynet.md/api/docs/ro/errors-and-statuses.md)). Când o plată reală eșuează, clientul este doar redirecționat la `LinkUrlCancel` și nu se trimite notificare.

## Ce face testele să eșueze

- **`Order` reutilizat.** Același `Order` cu date diferite sau un `Order` deja achitat dă `500 TECHNICAL_ERROR`. Portalul generează automat un `Order` nou (ora curentă în milisecunde).
- **`ExpiryDate` în trecut.** Folosiți o dată viitoare în ora locală Chișinău. Portalul pune sfârșitul zilei de mâine.
- **Sume în MDL în loc de unități minime.** `100` înseamnă 1,00 MDL.
- **Token expirat.** Tokenul este valabil aproximativ 4 ore; după `401` apelați din nou `/auth`.
- **Produsele nu se potrivesc.** Dacă trimiteți `Products`, trimiteți toate câmpurile produsului și păstrați valorile `Amount` coerente cu `Amount` al serviciului.

## Scenarii de test

| # | Scenariu | Cum | Rezultat așteptat |
|---|---|---|---|
| 1 | Autentificare | `POST /auth` cu datele de test | `200`, `access_token` |
| 2 | Parolă greșită | `POST /auth` cu parolă greșită | `401`, `AUTHENTICATION_FAILED` |
| 3 | Creare comandă | `POST /api/order` | `200`, `paymentId`, `paymentLink`, `status` `1` |
| 4 | Repetarea aceleiași cereri | trimiteți scenariul 3 din nou, nemodificat | același `paymentId` și `paymentLink` |
| 5 | Același `Order`, altă sumă | modificați `Amount`, păstrați `Order` | `500`, `TECHNICAL_ERROR` |
| 6 | Cerere invalidă | `POST /api/order` fără `Services` | `400` cu obiectul `errorInfo` (câmpul lipsă în `errors`) |
| 7 | Fără token | `POST /api/order` fără `Authorization` | `401`, `UNAUTHORIZED` |
| 8 | Plată | deschideți `paymentLink`, plătiți cu cardul de test | revenire la `LinkUrlSuccess` |
| 9 | Status | `GET /api/order/merchant/{Order}` | plată cu `paidDate` completat |
| 10 | Comandă necunoscută | `GET /api/order/{id}` cu un ID aleator | `404`, `NOT_FOUND_RECORD` |
| 11 | Notificare | **Simulator notificări** → URL-ul dvs. | handler-ul verifică `Hash` și returnează `200` |
| 12 | Hash greșit | trimiteți o notificare cu `Amount` modificat | handler-ul o respinge |
| 13 | Notificare duplicată | trimiteți aceeași notificare de două ori | handler-ul o procesează o singură dată |
| 14 | Hosted checkout | **Formular checkout (încercați)** | se deschide pagina de plată de test Paynet |
| 15 | Rambursare | `POST /api/order/refund` pentru o plată achitată | `200`; `status` devine `5` (integrală) sau `6` (parțială) |
| 16 | Rambursare peste suma plătită | `RefundType` `partial`, `Amount` mai mare decât `PaidAmount` | `400 INVALID_PARAMETER` |
| 17 | Salvarea cardului (dacă este activată pentru `SaleAreaCode`) | `POST /api/order` cu `Customer`, plătiți păstrând bifa „salvează cardul” | notificarea `PAID` conține `CardLinkHash` |
| 18 | Plata cu card salvat (dacă este activată) | `POST /api/order` cu `CardLinkHash` și același `Customer` | pagina Paynet afișează cardul salvat |
| 19 | Clientul a plecat fără să plătească | deschideți `paymentLink`, închideți pagina, deschideți linkul din nou | `status` rămâne `1`, plata e încă posibilă |

## Răspunsuri simulate pentru testele de eșec

Refuzul băncii, erorile de rambursare și notificările deteriorate nu pot fi reproduse cu cardul de test. Pentru testele automate ale integrării folosiți aceste răspunsuri gata — sunt luate din răspunsuri reale ale mediului de test, iar notificările sunt semnate cu cheia de test. Lista completă: [mocks/index.json](https://docs.paynet.md/api/mocks/index.json).

| Fișier | Ce simulează | Ce trebuie să facă codul dvs. |
|---|---|---|
| [payment-status-3.json](https://docs.paynet.md/api/mocks/payment-status-3.json) | Plata este încă în procesare | Așteptați, nu creați o comandă nouă |
| [payment-status-5-declined.json](https://docs.paynet.md/api/mocks/payment-status-5-declined.json) | Refuzată de bancă | Oferiți o nouă încercare cu un `Order` nou |
| [payment-status-5-refunded.json](https://docs.paynet.md/api/mocks/payment-status-5-refunded.json), [payment-status-6.json](https://docs.paynet.md/api/mocks/payment-status-6.json) | Rambursare integrală și parțială | Nu onorați comanda din nou |
| [refund-400-amount-or-second.json](https://docs.paynet.md/api/mocks/refund-400-amount-or-second.json), [refund-404-unpaid.json](https://docs.paynet.md/api/mocks/refund-404-unpaid.json) | Erori de rambursare | Afișați o eroare clară, nu repetați automat |
| [order-500-repeated-order.json](https://docs.paynet.md/api/mocks/order-500-repeated-order.json), [order-400-errorinfo.json](https://docs.paynet.md/api/mocks/order-400-errorinfo.json) | `Order` repetat, cerere ilizibilă | Tratați ambele formate de eroare |
| [error-401-token.json](https://docs.paynet.md/api/mocks/error-401-token.json) | Token expirat | Obțineți un token nou și repetați o dată |
| [notification-paid.json](https://docs.paynet.md/api/mocks/notification-paid.json) | Notificare `PAID` validă | Răspundeți `200`, onorați o singură dată |
| [notification-paid-wrong-hash.json](https://docs.paynet.md/api/mocks/notification-paid-wrong-hash.json) | `Hash` greșit | Răspundeți `400`, nu schimbați nimic |
| [notification-paid-tampered-paidamount.json](https://docs.paynet.md/api/mocks/notification-paid-tampered-paidamount.json) | `Hash` valid, dar `PaidAmount` nesemnat modificat | Confirmarea prin API trebuie să trimită comanda la verificare |

`payment-status-5-declined.json` este construit: valoarea `status` este reală, celelalte câmpuri sunt ca la o plată neachitată.

## Testare de pe acest portal

Butoanele „Test API Request” apelează API-ul de test direct din browserul dvs. Funcționează pe domeniul oficial al portalului. Dacă deschideți o copie a portalului de la altă adresă, browserul poate bloca apelurile (CORS) — folosiți atunci cURL sau Postman. O colecție Postman gata de utilizare este descrisă mai jos.

## Postman

Colecția gata făcută funcționează imediat după import, nu trebuie modificat nimic.

1. Descărcați [colecția](https://docs.paynet.md/api/postman/paynet-ecom.postman_collection.json) și [mediul de test](https://docs.paynet.md/api/postman/paynet-test.postman_environment.json) (le găsiți și în meniul lateral, sub butonul „Postman collection”).
2. În Postman: **Import** → selectați ambele fișiere → în dreapta sus alegeți mediul **Paynet — TEST**.
3. Rulați **1. Payments → Create order**. Tokenul se obține automat; `Order` și `ExpiryDate` sunt noi de fiecare dată.
4. În **Postman Console** apare `paymentLink` — deschideți-l și plătiți cu cardul de test.
5. Rulați **Get payment by Order**: `status` = `4` înseamnă achitat. Apoi puteți rula **Refund**.

| Ce face colecția singură | Cum |
|---|---|
| Obține și reînnoiește tokenul | Înainte de fiecare cerere, dacă tokenul lipsește sau expiră curând |
| Creează o comandă unică | `Order` = ora curentă în ms, `ExpiryDate` = mâine, ora Chișinăului |
| Transmite datele între cereri | Salvează `paymentId`, `paymentLink`, `lastOrder`, `cardLinkHash` |
| Calculează perioadele | Căutare — ultimele 24 de ore în ora Chișinăului, extras — ultimele 7 zile |
| Afișează erorile | Codul, mesajul, `details` și `traceId` în Postman Console |

Dosarul **5. Error examples** provoacă intenționat erorile `401`, `400` și `404`, ca să vedeți cum arată.

Pentru producție, importați [mediul PRODUCTION](https://docs.paynet.md/api/postman/paynet-production.postman_environment.json) și completați **propriile** `username`, `password`, `saleAreaCode`. Nu distribuiți acest fișier după completare.
