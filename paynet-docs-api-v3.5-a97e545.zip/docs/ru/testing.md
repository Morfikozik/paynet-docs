# Тестирование

## Тестовая среда

| Что | Значение |
|---|---|
| Базовый URL API | `https://ecom-api-test.paynet.md` |
| URL формы hosted checkout | `https://test.paynet.md/ecom/checkout` |
| Логин / пароль API | `771064` / `sLgMnGWJ` |
| Код мерчанта | `265505` |
| Код торговой зоны | `onlidocumentation_md` |
| Секретный ключ для подписи hosted checkout | `F90D6485-9CCC-458B-96A3-8958AF9B4458` |
| Секретный ключ для уведомлений | `D9873689-E5F8-4272-A67F-0D8BA3F9BAA7` |

Эти учётные данные общие для всех, кто тестирует на портале: чужие тестовые платежи видны в поиске и выписках. Если нужна изолированная среда, запросите в Paynet собственного тестового мерчанта.

## Тестовая карта

| Карта | Срок | CVV | Результат |
|---|---|---|---|
| Visa `4111 1111 1111 1111` | `12/27` | `777` | успешный платёж |

Тестовыми картами можно проверить только успешную оплату: карт для отказа и 3-D Secure нет. Обработку отказа всё равно нужно реализовать и проверить на имитированных ответах API: `status` = `5` и возврат покупателя на `LinkUrlCancel` (см. [Неуспешная оплата](https://docs.paynet.md/api/docs/ru/errors-and-statuses.md)). Когда реальный платёж не проходит, покупатель просто перенаправляется на `LinkUrlCancel`, уведомление не отправляется.

## Из-за чего тесты падают

- **Повторный `Order`.** Тот же `Order` с другими данными или уже оплаченный `Order` даёт `500 TECHNICAL_ERROR`. Портал генерирует новый `Order` сам (текущее время в миллисекундах).
- **`ExpiryDate` в прошлом.** Указывайте будущую дату по местному времени Кишинёва. Портал ставит конец завтрашнего дня.
- **Суммы в MDL вместо минимальных единиц.** `100` — это 1,00 MDL.
- **Истёкший токен.** Токен живёт около 4 часов; после `401` снова вызовите `/auth`.
- **Товары не сходятся.** Если передаёте `Products`, передавайте все поля товара и следите, чтобы `Amount` совпадали с `Amount` услуги.

## Тестовые сценарии

| # | Сценарий | Как | Ожидается |
|---|---|---|---|
| 1 | Аутентификация | `POST /auth` с тестовыми данными | `200`, `access_token` |
| 2 | Неверный пароль | `POST /auth` с неверным паролем | `401`, `AUTHENTICATION_FAILED` |
| 3 | Создание заказа | `POST /api/order` | `200`, `paymentId`, `paymentLink`, `status` `1` |
| 4 | Повтор того же запроса | отправить сценарий 3 ещё раз без изменений | тот же `paymentId` и `paymentLink` |
| 5 | Тот же `Order`, другая сумма | изменить `Amount`, оставить `Order` | `500`, `TECHNICAL_ERROR` |
| 6 | Неверный запрос | `POST /api/order` без `Services` | `400` с объектом `errorInfo` (недостающее поле в `errors`) |
| 7 | Без токена | `POST /api/order` без `Authorization` | `401`, `UNAUTHORIZED` |
| 8 | Оплата | открыть `paymentLink`, оплатить тестовой картой | возврат на `LinkUrlSuccess` |
| 9 | Статус | `GET /api/order/merchant/{Order}` | платёж с заполненным `paidDate` |
| 10 | Неизвестный заказ | `GET /api/order/{id}` со случайным ID | `404`, `NOT_FOUND_RECORD` |
| 11 | Уведомление | **Симулятор уведомлений** → ваш URL | обработчик проверяет `Hash` и возвращает `200` |
| 12 | Неверный хэш | отправить уведомление с изменённым `Amount` | обработчик его отклоняет |
| 13 | Повторное уведомление | отправить одно уведомление дважды | обработчик обрабатывает его один раз |
| 14 | Hosted checkout | **Форма checkout (попробовать)** | открывается тестовая страница оплаты Paynet |
| 15 | Возврат | `POST /api/order/refund` по оплаченному платежу | `200`; `status` становится `5` (полный) или `6` (частичный) |
| 16 | Возврат больше оплаченного | `RefundType` `partial`, `Amount` больше `PaidAmount` | `400 INVALID_PARAMETER` |
| 17 | Сохранение карты (если включено для вашего `SaleAreaCode`) | `POST /api/order` с `Customer`, оплатить, оставив галочку «сохранить карту» | в уведомлении `PAID` заполнен `CardLinkHash` |
| 18 | Оплата сохранённой картой (если включено) | `POST /api/order` с `CardLinkHash` и тем же `Customer` | на странице Paynet показана сохранённая карта |
| 19 | Покупатель ушёл без оплаты | открыть `paymentLink` и закрыть страницу, затем открыть ссылку снова | `status` остаётся `1`, оплатить можно |

## Имитированные ответы для тестов отказов

Отказ банка, ошибки возврата и повреждённые уведомления не воспроизвести тестовой картой. Для автотестов вашей интеграции используйте готовые ответы — они взяты из реальных ответов тестовой среды, уведомления подписаны тестовым ключом. Полный список: [mocks/index.json](https://docs.paynet.md/api/mocks/index.json).

| Файл | Что имитирует | Что должен сделать ваш код |
|---|---|---|
| [payment-status-3.json](https://docs.paynet.md/api/mocks/payment-status-3.json) | Оплата ещё обрабатывается | Ждать, не создавать новый заказ |
| [payment-status-5-declined.json](https://docs.paynet.md/api/mocks/payment-status-5-declined.json) | Банк отклонил оплату | Предложить новую попытку с новым `Order` |
| [payment-status-5-refunded.json](https://docs.paynet.md/api/mocks/payment-status-5-refunded.json), [payment-status-6.json](https://docs.paynet.md/api/mocks/payment-status-6.json) | Полный и частичный возврат | Не выполнять заказ повторно |
| [refund-400-amount-or-second.json](https://docs.paynet.md/api/mocks/refund-400-amount-or-second.json), [refund-404-unpaid.json](https://docs.paynet.md/api/mocks/refund-404-unpaid.json) | Ошибки возврата | Показать понятную ошибку, не повторять автоматически |
| [order-500-repeated-order.json](https://docs.paynet.md/api/mocks/order-500-repeated-order.json), [order-400-errorinfo.json](https://docs.paynet.md/api/mocks/order-400-errorinfo.json) | Повтор `Order`, нечитаемый запрос | Обработать оба формата ошибок |
| [error-401-token.json](https://docs.paynet.md/api/mocks/error-401-token.json) | Просроченный токен | Получить новый токен и повторить запрос один раз |
| [notification-paid.json](https://docs.paynet.md/api/mocks/notification-paid.json) | Верное уведомление `PAID` | Ответить `200`, выполнить заказ один раз |
| [notification-paid-wrong-hash.json](https://docs.paynet.md/api/mocks/notification-paid-wrong-hash.json) | Неверный `Hash` | Ответить `400`, ничего не менять |
| [notification-paid-tampered-paidamount.json](https://docs.paynet.md/api/mocks/notification-paid-tampered-paidamount.json) | Верный `Hash`, но изменён неподписанный `PaidAmount` | Сверка через API должна отправить заказ на проверку |

Ответ `payment-status-5-declined.json` собран вручную: значение `status` реальное, остальные поля — как у неоплаченного платежа.

## Тестирование с этого портала

Кнопки «Test API Request» вызывают тестовый API прямо из вашего браузера. Это работает на официальном домене портала. Если открыть копию портала с другого адреса, браузер может заблокировать вызовы (CORS) — тогда используйте cURL или Postman. Готовая коллекция Postman описана ниже.

## Postman

Готовая коллекция работает сразу после импорта, ничего править не нужно.

1. Скачайте [коллекцию](https://docs.paynet.md/api/postman/paynet-ecom.postman_collection.json) и [тестовое окружение](https://docs.paynet.md/api/postman/paynet-test.postman_environment.json) (они же — в боковом меню под кнопкой «Postman collection»).
2. В Postman: **Import** → выберите оба файла → справа вверху выберите окружение **Paynet — TEST**.
3. Запустите **1. Payments → Create order**. Токен получается автоматически, `Order` и `ExpiryDate` каждый раз новые.
4. В **Postman Console** появится `paymentLink` — откройте его и оплатите тестовой картой.
5. Запустите **Get payment by Order**: `status` = `4` — оплачено. Затем можно выполнить **Refund**.

| Что делает коллекция сама | Как |
|---|---|
| Получает и обновляет токен | Перед каждым запросом, если токена нет или он скоро истечёт |
| Создаёт уникальный заказ | `Order` = текущее время в мс, `ExpiryDate` = завтра по Кишинёву |
| Передаёт данные между запросами | Сохраняет `paymentId`, `paymentLink`, `lastOrder`, `cardLinkHash` |
| Считает периоды | Поиск — последние 24 часа по времени Кишинёва, выписка — последние 7 дней |
| Показывает ошибки | Код, сообщение, `details` и `traceId` в Postman Console |

Папка **5. Error examples** специально вызывает ошибки `401`, `400` и `404`, чтобы было видно, как они выглядят.

Для продакшна импортируйте [окружение PRODUCTION](https://docs.paynet.md/api/postman/paynet-production.postman_environment.json) и заполните **свои** `username`, `password`, `saleAreaCode`. Не делитесь этим файлом после заполнения.
